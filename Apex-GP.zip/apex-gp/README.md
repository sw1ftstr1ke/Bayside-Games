# Apex GP — 3D Formula Racing Simulator

A browser-based, original open-wheel racing simulator built with Three.js. It is designed to run as a static website and deploy directly to GitHub Pages.

## Features

- Procedural 3D Ember Coast Grand Prix circuit with asphalt, kerbs, barriers, pit lane, grandstands, paddock buildings, trees, lighting and atmospheric sky.
- Detailed fictional single-seater with front/rear wings, sculpted nose, sidepods, halo, cockpit/driver helmet, suspension, slick tyres, rims, diffuser and exhaust.
- Chase and cockpit cameras.
- Time-trial session with 3-lap counter, live lap timer, sector splits, last lap and personal best.
- Eight-speed transmission with automatic or manual shifting.
- Driving model with throttle, braking, steering, aerodynamic drag/downforce, tyre grip, off-track penalties, traction assistance and basic damage.
- Soft / medium / hard tyre compounds with thermal behaviour, wear and grip loss.
- Hybrid energy store with balanced, hot-lap and harvest strategies.
- DRS activation zones, fuel consumption and basic car-health telemetry.
- Live speed, RPM, gear, driver inputs, energy, tyres, circuit map and car-status HUD.
- Keyboard, mouse-click and mobile touch controls.

## Run locally

This is a static site. You can serve the project directory with any local static server. For example, with Python installed:

```bash
python -m http.server 8000
```

Then open <http://localhost:8000>.

The app imports Three.js from jsDelivr through an import map, so internet access is required when loading the page. No build step or package installation is needed.

## Controls

| Input | Action |
|---|---|
| W / ↑ | Throttle |
| S / ↓ / Space | Brake |
| A / ← | Steer left |
| D / → | Steer right |
| Shift | Upshift (manual transmission) |
| Ctrl | Downshift (manual transmission) |
| E | Toggle DRS in an enabled zone |
| C | Toggle chase / cockpit camera |
| P / Esc | Pause / resume |
| R | Reset car to start line |

Use **Driver Setup** in the top-right UI to choose transmission, tyre compound, driving assistance and ERS strategy.

## Publish to GitHub Pages

1. Create a new GitHub repository and add these project files to its root.
2. In the repository, open **Settings → Pages**.
3. Under **Build and deployment**, select **GitHub Actions**.
4. Push to the `main` branch. The included workflow at `.github/workflows/pages.yml` publishes the static project.
5. Open the Pages URL shown in the repository settings.

The workflow is configured to publish the repository root. If you use a different default branch, change the workflow trigger branch in `pages.yml`.

## Project layout

```text
apex-gp/
├── .github/workflows/pages.yml
├── index.html
├── README.md
├── LICENSE
└── src/
    ├── car.js
    ├── main.js
    ├── style.css
    └── track.js
```

## Simulation scope

This project is a playable real-time racing-game prototype, not a validated engineering simulator. The vehicle model is a deliberately simplified bicycle / force model; it does not model real team power-unit maps, tyre carcass construction, full suspension kinematics, CFD aerodynamics, wind tunnel data, race-control regulations, multiplayer, licensed championship data or exact circuit geometry. The circuit and car are fictional. The goal is a convincing driving experience and a solid foundation for future development.

## License

MIT. See `LICENSE`.

### Push from your computer

After extracting the ZIP and creating an empty `apex-gp` repository on GitHub, run:

```bash
git init -b main
git add .
git commit -m "Build Apex GP racing simulator"
git remote add origin https://github.com/YOUR_USERNAME/apex-gp.git
git push -u origin main
```

Alternatively, with the GitHub CLI authenticated (`gh auth login`):

```bash
gh repo create apex-gp --public --source=. --remote=origin --push
```
