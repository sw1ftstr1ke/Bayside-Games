import * as THREE from 'three';

const paint = new THREE.MeshPhysicalMaterial({ color: 0xe85d36, metalness: .35, roughness: .26, clearcoat: 1, clearcoatRoughness: .15 });
const carbon = new THREE.MeshStandardMaterial({ color: 0x10171d, metalness: .55, roughness: .5 });
const carbonSoft = new THREE.MeshStandardMaterial({ color: 0x202b33, metalness: .4, roughness: .6 });
const accent = new THREE.MeshStandardMaterial({ color: 0xe8edf0, metalness: .45, roughness: .3 });
const tireMat = new THREE.MeshStandardMaterial({ color: 0x141719, roughness: .95 });
const rimMat = new THREE.MeshStandardMaterial({ color: 0x89949a, metalness: .8, roughness: .24 });
const glass = new THREE.MeshPhysicalMaterial({ color: 0x182b39, metalness: .4, roughness: .12, transparent: true, opacity: .75 });

function box(parent, size, pos, mat, rot = null) {
  const m = new THREE.Mesh(new THREE.BoxGeometry(...size), mat); m.position.set(...pos); if (rot) m.rotation.set(...rot); m.castShadow = true; m.receiveShadow = true; parent.add(m); return m;
}
function cylinder(parent, rTop, rBottom, h, pos, mat, rot = [0, 0, 0], radial = 16) {
  const m = new THREE.Mesh(new THREE.CylinderGeometry(rTop, rBottom, h, radial), mat); m.position.set(...pos); m.rotation.set(...rot); m.castShadow = true; parent.add(m); return m;
}
function rod(parent, a, b, radius, mat) {
  const start = new THREE.Vector3(...a), end = new THREE.Vector3(...b), d = end.clone().sub(start);
  const m = new THREE.Mesh(new THREE.CylinderGeometry(radius, radius, d.length(), 7), mat);
  m.position.copy(start).add(end).multiplyScalar(.5); m.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), d.normalize()); m.castShadow = true; parent.add(m); return m;
}

export function createCar(scene) {
  const root = new THREE.Group(); scene.add(root);
  const chassis = new THREE.Group(); root.add(chassis);
  // Floor, venturi tunnels, diffuser and central monocoque.
  box(chassis, [1.45, .18, 3.3], [0, .25, -.05], carbon);
  box(chassis, [1.05, .16, 2.2], [0, .42, -.25], carbonSoft);
  box(chassis, [.78, .62, 1.85], [0, .73, -.25], paint);
  // Shoulder pods and aerodynamic sidepods.
  for (const sign of [-1, 1]) {
    const pod = new THREE.Mesh(new THREE.CapsuleGeometry(.31, 1.25, 5, 10), paint); pod.rotation.x = Math.PI / 2; pod.position.set(sign * .83, .64, -.38); pod.scale.set(1, 1, .78); pod.castShadow = true; chassis.add(pod);
    box(chassis, [.55, .1, 1.7], [sign * .94, .42, -.45], carbon);
    box(chassis, [.48, .16, .8], [sign * .96, .7, -.1], accent);
    // Sidepod inlet and cooling louvre details.
    box(chassis, [.08, .24, .42], [sign * 1.09, .8, .05], carbon, [0, 0, sign * -.16]);
    for (let j = 0; j < 4; j++) box(chassis, [.025, .018, .45], [sign * 1.1, .83 + j * .045, -.63], accent);
  }
  // Sculpted nose cone and front bulkhead.
  const nose = new THREE.Mesh(new THREE.CylinderGeometry(.16, .48, 2.25, 10, 1), paint); nose.rotation.x = Math.PI / 2; nose.position.set(0, .54, 1.65); nose.castShadow = true; chassis.add(nose);
  box(chassis, [.48, .12, .45], [0, .35, 2.27], carbon);
  box(chassis, [.34, .09, .36], [0, .65, 2.25], accent);
  // Front and rear wings with multiple planes/endplates.
  box(chassis, [3.1, .12, .55], [0, .24, 2.7], carbon);
  box(chassis, [3.45, .08, .23], [0, .36, 2.88], paint);
  for (const sign of [-1, 1]) {
    box(chassis, [.08, .62, .62], [sign * 1.66, .42, 2.72], paint, [0, 0, sign * -.1]);
    rod(chassis, [sign * .28, .25, 2.4], [sign * .72, .78, 2.1], .035, carbon);
    // Floor fences and bargeboard fins.
    box(chassis, [.06, .38, 1.1], [sign * 1.26, .54, -.65], carbon, [0, 0, sign * .08]);
    box(chassis, [.06, .2, .8], [sign * 1.22, .47, -1.14], accent, [0, 0, sign * -.1]);
  }
  // Airbox, engine cover, shark fin, cockpit opening and halo.
  const airbox = new THREE.Mesh(new THREE.CylinderGeometry(.3, .42, .6, 10), carbon); airbox.rotation.x = Math.PI / 2; airbox.position.set(0, 1.28, -.76); chassis.add(airbox);
  box(chassis, [.08, .72, 1.65], [0, 1.12, -.65], paint, [0, 0, 0]);
  const cockpit = new THREE.Mesh(new THREE.CylinderGeometry(.47, .42, .18, 12), carbon); cockpit.rotation.x = Math.PI / 2; cockpit.position.set(0, 1.07, .9); chassis.add(cockpit);
  const helmet = new THREE.Mesh(new THREE.SphereGeometry(.3, 16, 12), new THREE.MeshStandardMaterial({ color: 0xf2e5ca, roughness: .45 })); helmet.position.set(0, 1.22, .84); helmet.scale.set(.9, 1, 1.1); chassis.add(helmet);
  const visor = new THREE.Mesh(new THREE.SphereGeometry(.22, 16, 10), glass); visor.position.set(0, 1.26, 1.02); visor.scale.set(1.02, .62, .5); chassis.add(visor);
  // Halo hoop built from a smooth tube curve.
  const haloCurve = new THREE.CatmullRomCurve3([new THREE.Vector3(-.55, 1.08, .54), new THREE.Vector3(-.5, 1.66, .6), new THREE.Vector3(-.28, 1.78, .6), new THREE.Vector3(0, 1.83, .6), new THREE.Vector3(.28, 1.78, .6), new THREE.Vector3(.5, 1.66, .6), new THREE.Vector3(.55, 1.08, .54)]);
  const halo = new THREE.Mesh(new THREE.TubeGeometry(haloCurve, 28, .045, 8, false), rimMat); chassis.add(halo);
  rod(chassis, [0, 1.8, .6], [0, 1.05, 1.24], .05, rimMat);
  // Rear wing pylons, main plane and DRS flap.
  box(chassis, [2.35, .12, .5], [0, 1.53, -2.0], carbon);
  box(chassis, [2.65, .1, .18], [0, 2.05, -1.94], paint);
  box(chassis, [2.7, .08, .16], [0, 2.26, -1.9], carbon);
  for (const sign of [-1, 1]) {
    box(chassis, [.08, .85, .65], [sign * 1.25, 1.76, -1.98], paint);
    rod(chassis, [sign * .58, 1.45, -1.85], [sign * .58, 2, -1.93], .055, carbon);
  }
  // Rear diffuser and exhaust.
  box(chassis, [1.5, .13, .7], [0, .32, -1.9], carbon);
  cylinder(chassis, .095, .095, .38, [0, .75, -1.95], rimMat, [Math.PI / 2, 0, 0], 14);
  // Wheels, brake rotors, rims and suspension wishbones.
  const wheels = [];
  for (const xSign of [-1, 1]) for (const zSign of [-1, 1]) {
    const front = zSign > 0, x = xSign * 1.18, z = front ? 1.78 : -1.42;
    const wheel = new THREE.Group(); wheel.position.set(x, .55, z); chassis.add(wheel); wheels.push({ mesh: wheel, front, xSign, zSign });
    const tire = new THREE.Mesh(new THREE.CylinderGeometry(.57, .57, .42, 32, 1), tireMat); tire.rotation.z = Math.PI / 2; tire.castShadow = true; tire.receiveShadow = true; wheel.add(tire);
    const rim = new THREE.Mesh(new THREE.CylinderGeometry(.34, .34, .438, 24, 1), rimMat); rim.rotation.z = Math.PI / 2; wheel.add(rim);
    const hub = new THREE.Mesh(new THREE.CylinderGeometry(.09, .09, .45, 12), carbon); hub.rotation.z = Math.PI / 2; wheel.add(hub);
    for (let spoke = 0; spoke < 8; spoke++) {
      const a = spoke * Math.PI / 4;
      const spokeMesh = box(wheel, [.035, .025, .24], [0, Math.sin(a) * .13, Math.cos(a) * .13], accent, [a, 0, 0]);
      spokeMesh.position.x = 0;
    }
    // Carbon arms create the exposed pushrod suspension silhouette.
    rod(chassis, [xSign * .62, .42, z + (front ? .15 : -.12)], [x, .58, z], .035, carbon);
    rod(chassis, [xSign * .66, .85, z + (front ? -.18 : .18)], [x, .72, z], .03, rimMat);
    rod(chassis, [xSign * .7, .42, z + (front ? -.28 : .26)], [x, .52, z], .028, carbonSoft);
  }
  // Small mirrors and aerodynamic fins.
  for (const sign of [-1, 1]) {
    rod(chassis, [sign * .55, 1.04, .55], [sign * .86, 1.22, .48], .035, carbon);
    box(chassis, [.26, .11, .2], [sign * .91, 1.25, .47], carbon);
  }
  // Low emissive rear rain light.
  const rearLight = new THREE.Mesh(new THREE.BoxGeometry(.24, .14, .06), new THREE.MeshBasicMaterial({ color: 0xff3329 })); rearLight.position.set(0, .6, -2.35); chassis.add(rearLight);
  const shadow = new THREE.Mesh(new THREE.CircleGeometry(2.3, 32), new THREE.MeshBasicMaterial({ color: 0x05090d, transparent: true, opacity: .3 })); shadow.rotation.x = -Math.PI / 2; shadow.position.y = .012; root.add(shadow);
  return { root, chassis, wheels, shadow };
}
