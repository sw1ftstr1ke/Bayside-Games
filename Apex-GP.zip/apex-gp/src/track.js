import * as THREE from 'three';

const controlPoints = [
  [0, 0, 0], [0, 0, 118], [30, 0, 183], [96, 0, 208], [178, 0, 184],
  [225, 0, 128], [222, 0, 56], [177, 0, 7], [105, 0, -4],
  [83, 0, -80], [116, 0, -146], [80, 0, -209], [5, 0, -234],
  [-79, 0, -215], [-154, 0, -163], [-190, 0, -91], [-173, 0, -24],
  [-113, 0, 26], [-100, 0, 96], [-53, 0, 153], [-5, 0, 174]
];

function ribbonGeometry(samples, width, offset = 0, yOffset = 0) {
  const positions = [], uvs = [], indices = [];
  for (let i = 0; i <= samples.length; i++) {
    const p = samples[i % samples.length];
    const side = new THREE.Vector3(-p.tangent.z, 0, p.tangent.x).normalize();
    const left = p.point.clone().addScaledVector(side, width / 2 + offset);
    const right = p.point.clone().addScaledVector(side, -width / 2 - offset);
    left.y += yOffset; right.y += yOffset;
    positions.push(left.x, left.y, left.z, right.x, right.y, right.z);
    uvs.push(0, i / samples.length * 35, 1, i / samples.length * 35);
    if (i < samples.length) {
      const a = i * 2, b = a + 1, c = a + 2, d = a + 3;
      indices.push(a, b, c, b, d, c);
    }
  }
  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  geo.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
  geo.setIndex(indices); geo.computeVertexNormals();
  return geo;
}

export function buildTrack(scene) {
  const curve = new THREE.CatmullRomCurve3(controlPoints.map(p => new THREE.Vector3(...p)), true, 'catmullrom', 0.45);
  const length = curve.getLength();
  const count = 1800;
  const samples = [];
  for (let i = 0; i < count; i++) {
    const t = i / count;
    samples.push({ point: curve.getPointAt(t), tangent: curve.getTangentAt(t).normalize(), t, s: t * length });
  }
  const grass = new THREE.Mesh(new THREE.PlaneGeometry(1800, 1800), new THREE.MeshStandardMaterial({ color: 0x456548, roughness: 1 }));
  grass.rotation.x = -Math.PI / 2; grass.position.y = -0.45; grass.receiveShadow = true; scene.add(grass);
  const road = new THREE.Mesh(ribbonGeometry(samples, 15), new THREE.MeshStandardMaterial({ color: 0x272d32, roughness: 0.93, metalness: 0.01, side: THREE.DoubleSide }));
  road.receiveShadow = true; road.renderOrder = 1; scene.add(road);
  const edgeMat = new THREE.MeshStandardMaterial({ color: 0xe8e8e3, roughness: 0.8, side: THREE.DoubleSide });
  const edge = new THREE.Mesh(ribbonGeometry(samples, 15.2, 0.08, 0.025), edgeMat); edge.renderOrder = 2; scene.add(edge);
  const innerRoad = new THREE.Mesh(ribbonGeometry(samples, 14.95, 0, 0.04), new THREE.MeshStandardMaterial({ color: 0x2b3034, roughness: 1, side: THREE.DoubleSide })); innerRoad.renderOrder = 3; scene.add(innerRoad);

  // Alternating kerb tiles along the road shoulders.
  const curbRed = new THREE.MeshStandardMaterial({ color: 0xd94836, roughness: 0.8, side: THREE.DoubleSide });
  const curbWhite = new THREE.MeshStandardMaterial({ color: 0xe7e6df, roughness: 0.8, side: THREE.DoubleSide });
  const curbGroup = new THREE.Group();
  for (let i = 0; i < count; i += 9) {
    const a = samples[i], b = samples[(i + 9) % count];
    const sideA = new THREE.Vector3(-a.tangent.z, 0, a.tangent.x).normalize();
    const sideB = new THREE.Vector3(-b.tangent.z, 0, b.tangent.x).normalize();
    for (const sign of [-1, 1]) {
      const verts = [];
      const pa = a.point.clone().addScaledVector(sideA, sign * 7.58); pa.y = 0.09;
      const pb = b.point.clone().addScaledVector(sideB, sign * 7.58); pb.y = 0.09;
      const qa = a.point.clone().addScaledVector(sideA, sign * 9.1); qa.y = 0.055;
      const qb = b.point.clone().addScaledVector(sideB, sign * 9.1); qb.y = 0.055;
      verts.push(pa, qa, pb, qa, qb, pb);
      const g = new THREE.BufferGeometry().setFromPoints(verts); g.computeVertexNormals();
      curbGroup.add(new THREE.Mesh(g, Math.floor(i / 9) % 2 ? curbRed : curbWhite));
    }
  }
  curbGroup.renderOrder = 4; scene.add(curbGroup);

  // Start/finish stripe and grid markers.
  const start = samples[0];
  const side = new THREE.Vector3(-start.tangent.z, 0, start.tangent.x).normalize();
  const line = new THREE.Mesh(new THREE.PlaneGeometry(15, 1.05), new THREE.MeshStandardMaterial({ color: 0xf4f5f2, roughness: 0.7, side: THREE.DoubleSide }));
  line.rotation.x = -Math.PI / 2; line.position.set(start.point.x, 0.075, start.point.z); line.rotation.z = -Math.atan2(start.tangent.x, start.tangent.z); scene.add(line);
  for (let i = 0; i < 8; i++) {
    const p = sampleAt(samples, length * (0.02 + i * 0.025));
    const grid = new THREE.Mesh(new THREE.PlaneGeometry(2.2, 4), new THREE.MeshStandardMaterial({ color: 0xbec7cb, side: THREE.DoubleSide, roughness: 0.95 }));
    grid.rotation.x = -Math.PI / 2; grid.position.set(p.point.x, 0.065, p.point.z); grid.rotation.z = -Math.atan2(p.tangent.x, p.tangent.z); scene.add(grid);
  }

  // Pit lane, barriers and track furniture.
  buildPitLane(scene, samples);
  buildScenery(scene, samples);
  buildStartGantry(scene, start);
  return { curve, samples, length, width: 15, sampleAt: d => sampleAt(samples, ((d % length) + length) % length) };
}

function sampleAt(samples, distance) {
  const index = Math.floor(distance / (samples[1].s - samples[0].s)) % samples.length;
  const next = (index + 1) % samples.length;
  const f = (distance - samples[index].s) / (samples[1].s - samples[0].s);
  return { point: samples[index].point.clone().lerp(samples[next].point, f), tangent: samples[index].tangent.clone().lerp(samples[next].tangent, f).normalize(), s: distance };
}

function buildPitLane(scene, samples) {
  const mat = new THREE.MeshStandardMaterial({ color: 0x30373c, roughness: 0.95, side: THREE.DoubleSide });
  const pitSamples = samples.slice(0, 180).map(s => ({ point: s.point.clone().add(new THREE.Vector3(0, 0, -20)), tangent: s.tangent }));
  const pit = new THREE.Mesh(ribbonGeometry(pitSamples, 7), mat); pit.position.y = 0.02; scene.add(pit);
  const wallMat = new THREE.MeshStandardMaterial({ color: 0xc8d0d4, roughness: 0.85 });
  for (let i = 0; i < 12; i++) {
    const s = samples[(i * 13) % 180];
    const side = new THREE.Vector3(-s.tangent.z, 0, s.tangent.x).normalize();
    const box = new THREE.Mesh(new THREE.BoxGeometry(8, 1.25, 1), wallMat);
    box.position.copy(s.point).addScaledVector(side, 15); box.position.y = .65; box.castShadow = true; scene.add(box);
  }
}

function buildScenery(scene, samples) {
  const standMat = new THREE.MeshStandardMaterial({ color: 0x64727d, roughness: 0.85 });
  const darkMat = new THREE.MeshStandardMaterial({ color: 0x263540, roughness: 0.9 });
  const bannerMat = new THREE.MeshStandardMaterial({ color: 0xe85d36, roughness: 0.65 });
  const glassMat = new THREE.MeshStandardMaterial({ color: 0x8ba6ae, metalness: .35, roughness: .28, transparent: true, opacity: .65 });
  // Grandstands outside key corners.
  const standPositions = [samples[175], samples[420], samples[760], samples[1110], samples[1440]];
  standPositions.forEach((s, i) => {
    const side = new THREE.Vector3(-s.tangent.z, 0, s.tangent.x).normalize();
    const direction = i % 2 ? 1 : -1;
    const group = new THREE.Group();
    const base = new THREE.Mesh(new THREE.BoxGeometry(37, 7, 10), standMat); base.position.y = 3.5; base.rotation.x = -0.18; base.castShadow = true; group.add(base);
    const roof = new THREE.Mesh(new THREE.BoxGeometry(41, .7, 12), darkMat); roof.position.y = 8; roof.castShadow = true; group.add(roof);
    for (let row = 0; row < 4; row++) {
      const stripe = new THREE.Mesh(new THREE.BoxGeometry(35, .26, .22), row % 2 ? bannerMat : glassMat); stripe.position.set(0, 1.7 + row * 1.15, 5.05); group.add(stripe);
    }
    group.position.copy(s.point).addScaledVector(side, direction * 29); group.position.y = 0; group.rotation.y = Math.atan2(s.tangent.x, s.tangent.z); scene.add(group);
  });
  // Safety barriers at intervals, deliberately broken into modules.
  const barrierMat = new THREE.MeshStandardMaterial({ color: 0xd9e0e2, roughness: .8 });
  const redMat = new THREE.MeshStandardMaterial({ color: 0xd94d39, roughness: .8 });
  for (let i = 20; i < samples.length; i += 34) {
    const s = samples[i];
    const side = new THREE.Vector3(-s.tangent.z, 0, s.tangent.x).normalize();
    for (const sign of [-1, 1]) {
      const pos = s.point.clone().addScaledVector(side, sign * 16.2);
      const box = new THREE.Mesh(new THREE.BoxGeometry(10, .9, .9), Math.floor(i / 34) % 3 ? barrierMat : redMat);
      box.position.set(pos.x, .45, pos.z); box.rotation.y = Math.atan2(s.tangent.x, s.tangent.z); box.castShadow = true; box.receiveShadow = true; scene.add(box);
    }
  }
  // Palms, scrub and low trees around the circuit perimeter.
  const trunkMat = new THREE.MeshStandardMaterial({ color: 0x5a4935, roughness: 1 });
  const leafMat = new THREE.MeshStandardMaterial({ color: 0x315f48, roughness: 1 });
  for (let i = 0; i < 80; i++) {
    const s = samples[(i * 23 + 8) % samples.length];
    const side = new THREE.Vector3(-s.tangent.z, 0, s.tangent.x).normalize();
    const sign = i % 2 ? 1 : -1;
    const offset = 42 + (i % 5) * 8;
    const p = s.point.clone().addScaledVector(side, sign * offset);
    const h = 4 + (i % 4) * .6;
    const trunk = new THREE.Mesh(new THREE.CylinderGeometry(.16, .25, h, 6), trunkMat); trunk.position.set(p.x, h / 2, p.z); trunk.castShadow = true; scene.add(trunk);
    const crown = new THREE.Mesh(new THREE.ConeGeometry(2.3 + (i % 3) * .4, 4.2, 7), leafMat); crown.position.set(p.x, h + 1.5, p.z); crown.castShadow = true; scene.add(crown);
  }
  // Distant paddock structures for a lived-in venue.
  for (let i = 0; i < 5; i++) {
    const x = -250 + i * 26, z = 235 + (i % 2) * 18;
    const building = new THREE.Mesh(new THREE.BoxGeometry(20, 9 + (i % 3) * 2, 10), i % 2 ? glassMat : darkMat);
    building.position.set(x, 5, z); building.castShadow = true; scene.add(building);
    const roof = new THREE.Mesh(new THREE.BoxGeometry(21, .8, 11), bannerMat); roof.position.set(x, 10, z); scene.add(roof);
  }
}

function buildStartGantry(scene, start) {
  const mat = new THREE.MeshStandardMaterial({ color: 0x101a23, metalness: .35, roughness: .55 });
  const glow = new THREE.MeshStandardMaterial({ color: 0xe85d36, emissive: 0x8d230f, emissiveIntensity: 1.6 });
  const side = new THREE.Vector3(-start.tangent.z, 0, start.tangent.x).normalize();
  const group = new THREE.Group();
  const beam = new THREE.Mesh(new THREE.BoxGeometry(15, .7, .8), mat); beam.position.y = 8; group.add(beam);
  for (const sign of [-1, 1]) { const leg = new THREE.Mesh(new THREE.BoxGeometry(.6, 8, .6), mat); leg.position.set(sign * 7.1, 4, 0); group.add(leg); }
  for (let i = 0; i < 5; i++) { const light = new THREE.Mesh(new THREE.SphereGeometry(.35, 12, 8), glow); light.position.set(-4 + i * 2, 7.2, -.55); group.add(light); }
  group.position.copy(start.point).addScaledVector(start.tangent, -3); group.rotation.y = Math.atan2(start.tangent.x, start.tangent.z); scene.add(group);
}
