import * as THREE from 'three';
import { buildTrack } from './track.js';
import { createCar } from './car.js';

const $ = id => document.getElementById(id);
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const lerp = (a, b, t) => a + (b - a) * t;
const formatTime = seconds => {
  if (!Number.isFinite(seconds) || seconds < 0) return '—:—.---';
  const m = Math.floor(seconds / 60), s = Math.floor(seconds % 60), ms = Math.floor((seconds % 1) * 1000);
  return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}.${String(ms).padStart(3, '0')}`;
};

const canvas = $('scene');
const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: 'high-performance' });
renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.18;

const scene = new THREE.Scene();
scene.background = new THREE.Color(0x92a8ae);
scene.fog = new THREE.FogExp2(0xa8b7b2, 0.0019);
const camera = new THREE.PerspectiveCamera(62, window.innerWidth / window.innerHeight, .1, 1600);
let cameraMode = 0;

scene.add(new THREE.HemisphereLight(0xd6e8f4, 0x516348, 2.0));
const sun = new THREE.DirectionalLight(0xffe5c4, 3.2);
sun.position.set(-180, 250, 130); sun.castShadow = true;
sun.shadow.mapSize.set(2048, 2048); sun.shadow.camera.left = -300; sun.shadow.camera.right = 300; sun.shadow.camera.top = 300; sun.shadow.camera.bottom = -300;
sun.shadow.normalBias = .035; sun.shadow.bias = -.00008; scene.add(sun);
const fill = new THREE.DirectionalLight(0x9ac8ef, .55); fill.position.set(180, 90, -170); scene.add(fill);

// Atmospheric sky dome, procedural clouds and distant hills.
const sky = new THREE.Mesh(new THREE.SphereGeometry(1200, 32, 18), new THREE.ShaderMaterial({
  side: THREE.BackSide,
  uniforms: { topColor: { value: new THREE.Color(0x59859e) }, bottomColor: { value: new THREE.Color(0xd7c8a7) }, offset: { value: 180 }, exponent: { value: .55 } },
  vertexShader: 'varying vec3 vWorldPosition; void main(){ vec4 wp=modelMatrix*vec4(position,1.0); vWorldPosition=wp.xyz; gl_Position=projectionMatrix*viewMatrix*wp; }',
  fragmentShader: 'uniform vec3 topColor; uniform vec3 bottomColor; uniform float offset; uniform float exponent; varying vec3 vWorldPosition; void main(){ float h=normalize(vWorldPosition+vec3(0.0,offset,0.0)).y; float f=max(pow(max(h,0.0),exponent),0.0); gl_FragColor=vec4(mix(bottomColor,topColor,f),1.0); }'
})); scene.add(sky);

const track = buildTrack(scene);
const car = createCar(scene);
const carState = { x: 0, z: 0, yaw: 0, speed: 0, lateralSpeed: 0, yawRate: 0, steer: 0, gear: 1, rpm: 6000, ers: 1, fuel: 1, health: 1, tireWear: 0, tireTemp: 76, lapCount: 0, lapStartedAt: 0, sessionStartedAt: 0, lastS: 0, currentS: 0, lastLap: null, bestLap: null, sectorStart: 0, sectors: [null, null, null], sectorIndex: 0, gearShiftTimer: 0, offTrackTime: 0, drs: false, running: false, paused: false, finished: false };
const startSample = track.sampleAt(0);
carState.x = startSample.point.x; carState.z = startSample.point.z;
carState.yaw = Math.atan2(startSample.tangent.x, startSample.tangent.z);
car.root.position.set(carState.x, 0, carState.z); car.root.rotation.y = carState.yaw;

const config = { transmission: 'auto', assist: true, tire: 'medium', ersMode: 'balanced', laps: 3 };
const compounds = { soft: { label: 'SOFT · C5', grip: 1.92, temp: 94 }, medium: { label: 'MEDIUM · C3', grip: 1.78, temp: 88 }, hard: { label: 'HARD · C1', grip: 1.65, temp: 83 } };
const keys = new Set();
const input = { throttle: 0, brake: 0, steer: 0, steerTarget: 0 };
const mini = $('minimap'), miniCtx = mini.getContext('2d');
const trackBounds = track.samples.reduce((b, s) => ({ minX: Math.min(b.minX, s.point.x), maxX: Math.max(b.maxX, s.point.x), minZ: Math.min(b.minZ, s.point.z), maxZ: Math.max(b.maxZ, s.point.z) }), { minX: Infinity, maxX: -Infinity, minZ: Infinity, maxZ: -Infinity });
const mapScale = Math.min((mini.width - 28) / (trackBounds.maxX - trackBounds.minX), (mini.height - 24) / (trackBounds.maxZ - trackBounds.minZ));
const mapPoint = p => ({ x: mini.width / 2 + (p.x - (trackBounds.minX + trackBounds.maxX) / 2) * mapScale, y: mini.height / 2 + (p.z - (trackBounds.minZ + trackBounds.maxZ) / 2) * mapScale });

// Construct the RPM shift lights once.
for (let i = 0; i < 18; i++) { const bar = document.createElement('i'); if (i > 13) bar.classList.add('hot'); $('rpm-bars').appendChild(bar); }
const rpmBars = [...$('rpm-bars').children];

function nearestTrack(x, z) {
  let bestIndex = 0, bestD2 = Infinity;
  // Coarse search followed by a local refinement: cheap enough for a full-rate render loop.
  for (let i = 0; i < track.samples.length; i += 3) {
    const p = track.samples[i].point, dx = x - p.x, dz = z - p.z, d2 = dx * dx + dz * dz;
    if (d2 < bestD2) { bestD2 = d2; bestIndex = i; }
  }
  for (let o = -3; o <= 3; o++) {
    const i = (bestIndex + o + track.samples.length) % track.samples.length;
    const p = track.samples[i].point, dx = x - p.x, dz = z - p.z, d2 = dx * dx + dz * dz;
    if (d2 < bestD2) { bestD2 = d2; bestIndex = i; }
  }
  const s = track.samples[bestIndex];
  const side = new THREE.Vector3(-s.tangent.z, 0, s.tangent.x);
  const lateral = (x - s.point.x) * side.x + (z - s.point.z) * side.z;
  return { s: s.s, distance: Math.sqrt(bestD2), lateral, point: s.point, tangent: s.tangent, index: bestIndex };
}

function resetCar() {
  const s = track.sampleAt(0);
  carState.x = s.point.x; carState.z = s.point.z; carState.yaw = Math.atan2(s.tangent.x, s.tangent.z);
  carState.speed = 0; carState.lateralSpeed = 0; carState.yawRate = 0; carState.steer = 0; carState.gear = 1; carState.rpm = 6000;
  car.root.position.set(carState.x, 0, carState.z); car.root.rotation.y = carState.yaw;
  carState.lastS = 0; carState.currentS = 0; input.throttle = input.brake = input.steer = 0;
  toast('CAR RESET TO START LINE');
}

function beginSession() {
  resetSession(false);
  carState.running = true; carState.paused = false; carState.finished = false;
  carState.sessionStartedAt = performance.now(); carState.lapStartedAt = carState.sessionStartedAt; carState.sectorStart = carState.sessionStartedAt;
  $('center-message').classList.add('hidden'); $('paused-panel').classList.add('hidden'); $('finish-panel').classList.add('hidden');
  $('session-label').textContent = 'TIME TRIAL'; $('race-message').textContent = 'GREEN FLAG — PUSH FOR A CLEAN LAP';
  toast('SESSION LIVE · GOOD LUCK');
}

function resetSession(keepRunning = false) {
  carState.speed = 0; carState.lateralSpeed = 0; carState.yawRate = 0; carState.steer = 0; carState.gear = 1; carState.rpm = 6000;
  carState.ers = 1; carState.fuel = 1; carState.health = 1; carState.tireWear = 0; carState.tireTemp = 76;
  carState.lapCount = 0; carState.lastLap = null; carState.bestLap = null; carState.sectorIndex = 0; carState.sectors = [null, null, null];
  carState.gearShiftTimer = 0; carState.offTrackTime = 0; carState.drs = false; carState.finished = false;
  resetCar();
  $('lap-current').textContent = '01'; $('lap-time').textContent = '00:00.000'; $('last-lap').textContent = '—:—.---'; $('best-lap').textContent = '—:—.---';
  ['sector-1', 'sector-2', 'sector-3'].forEach(id => $(id).textContent = '—:—.---');
  $('lap-progress-fill').style.width = '0%'; $('lap-total').textContent = String(config.laps).padStart(2, '0');
  $('finish-panel').classList.add('hidden');
  if (!keepRunning) { carState.running = false; carState.paused = false; $('center-message').classList.remove('hidden'); }
  updateHUD(0, null);
}

function pauseSession() {
  if (!carState.running || carState.finished) return;
  carState.paused = !carState.paused;
  $('paused-panel').classList.toggle('hidden', !carState.paused);
  $('pause-btn').querySelector('span').textContent = carState.paused ? '▶' : 'Ⅱ';
  if (!carState.paused) { const now = performance.now(); carState.lapStartedAt += now - carState.pauseStartedAt; carState.sessionStartedAt += now - carState.pauseStartedAt; carState.sectorStart += now - carState.pauseStartedAt; }
  else carState.pauseStartedAt = performance.now();
}

function finishSession() {
  carState.running = false; carState.finished = true; carState.drs = false;
  $('finish-best').textContent = formatTime(carState.bestLap);
  $('finish-summary').textContent = `${carState.lapCount} laps completed · ${carState.bestLap ? 'Personal best recorded' : 'No timed lap recorded'}.`;
  $('finish-panel').classList.remove('hidden'); $('race-message').textContent = 'CHEQUERED FLAG — SESSION COMPLETE';
}

let toastTimer;
function toast(message) {
  $('toast').textContent = message; $('toast').classList.add('show');
  clearTimeout(toastTimer); toastTimer = setTimeout(() => $('toast').classList.remove('show'), 1900);
}

function updateTiming(now, sNow) {
  if (!carState.running || carState.paused || carState.finished) return;
  const old = carState.lastS;
  const oneThird = track.length / 3, twoThirds = track.length * 2 / 3;
  if (old < oneThird && sNow >= oneThird && carState.sectorIndex === 0) {
    carState.sectors[0] = (now - carState.sectorStart) / 1000; carState.sectorIndex = 1;
    $('sector-1').textContent = formatTime(carState.sectors[0]); $('sector-tag').textContent = 'S2'; toast('SECTOR 1 COMPLETE');
    carState.sectorStart = now;
  }
  if (old < twoThirds && sNow >= twoThirds && carState.sectorIndex === 1) {
    carState.sectors[1] = (now - carState.sectorStart) / 1000; carState.sectorIndex = 2;
    $('sector-2').textContent = formatTime(carState.sectors[1]); $('sector-tag').textContent = 'S3'; toast('SECTOR 2 COMPLETE');
    carState.sectorStart = now;
  }
  if (old > track.length * .8 && sNow < track.length * .2) {
    const lap = (now - carState.lapStartedAt) / 1000;
    carState.sectors[2] = (now - carState.sectorStart) / 1000;
    carState.lastLap = lap; if (carState.bestLap === null || lap < carState.bestLap) carState.bestLap = lap;
    carState.lapCount++;
    $('last-lap').textContent = formatTime(carState.lastLap); $('best-lap').textContent = formatTime(carState.bestLap);
    $('sector-3').textContent = formatTime(carState.sectors[2]);
    $('lap-current').textContent = String(Math.min(carState.lapCount + 1, config.laps)).padStart(2, '0');
    $('sector-tag').textContent = 'S1'; $('sector-1').textContent = $('sector-2').textContent = '—:—.---';
    carState.sectorIndex = 0; carState.sectorStart = now; carState.lapStartedAt = now;
    carState.sectors = [null, null, null];
    $('race-message').textContent = carState.bestLap === lap ? 'PERSONAL BEST — KEEP THE MOMENTUM' : 'LAP COMPLETE — BUILD THE NEXT ONE';
    toast(`LAP ${carState.lapCount} · ${formatTime(lap)}${carState.bestLap === lap ? ' · BEST LAP' : ''}`);
    if (carState.lapCount >= config.laps) finishSession();
  }
  carState.lastS = sNow;
}

function physics(dt, now) {
  if (!carState.running || carState.paused || carState.finished) return;
  const maxSpeed = 101.5;
  const throttle = input.throttle, brake = input.brake;
  const speed = Math.abs(carState.speed);
  const speedKmh = speed * 3.6;
  const current = nearestTrack(carState.x, carState.z);
  const offTrack = Math.abs(current.lateral) > 7.65;
  const severeOff = Math.abs(current.lateral) > 11.5;
  const compound = compounds[config.tire];
  const aeroDownforce = .5 * 1.225 * 4.7 * speed * speed;
  const tempFactor = clamp(1 - Math.abs(carState.tireTemp - compound.temp) * .0045, .79, 1.02);
  const grip = compound.grip * (1 + aeroDownforce / (798 * 9.81)) * (1 - carState.tireWear * .42) * tempFactor * (severeOff ? .38 : offTrack ? .68 : 1);
  const maxLatAccel = clamp(grip * 9.81, 7, 52);

  // Steering is progressive: quick at low speed, deliberately slower at high speed.
  const speedSteer = 1 - .62 * clamp(speed / 92, 0, 1);
  const steeringAngle = carState.steer * .22 * speedSteer;
  let targetYawRate = speed / 5.7 * Math.tan(steeringAngle);
  targetYawRate = clamp(targetYawRate, -maxLatAccel / Math.max(speed, 2), maxLatAccel / Math.max(speed, 2));
  if (config.assist) targetYawRate *= .94;
  const yawResponse = 1 - Math.exp(-dt * (3.5 + speed * .035));
  carState.yawRate = lerp(carState.yawRate, targetYawRate, yawResponse);
  const desiredLateral = carState.steer * Math.min(speed * .045, 2.7);
  const lateralResponse = 1 - Math.exp(-dt * (offTrack ? 1.6 : 3.2));
  carState.lateralSpeed = lerp(carState.lateralSpeed, desiredLateral, lateralResponse);

  // Eight-speed hybrid power unit, simple torque curve and selectable energy strategy.
  const gearMax = [0, 14, 22, 31, 42, 55, 70, 86, 102];
  const gearRatio = [0, 1.00, .83, .69, .57, .47, .39, .33, .29];
  const gearFraction = clamp(speed / gearMax[carState.gear], 0, 1.25);
  carState.rpm = Math.round(clamp(5500 + gearFraction * 6900, 5500, 13200));
  const torqueCurve = .72 + .28 * Math.sin(clamp((carState.rpm - 5000) / 8500, 0, 1) * Math.PI * .82);
  const basePower = 710000 * torqueCurve;
  const deployKw = config.ersMode === 'hotlap' ? 145 : config.ersMode === 'harvest' ? 22 : 82;
  const availableDeploy = carState.ers > .015 ? deployKw * 1000 : 0;
  const drsActive = carState.drs && ((current.s / track.length > .06 && current.s / track.length < .22) || (current.s / track.length > .54 && current.s / track.length < .67));
  if (carState.drs && !drsActive) { carState.drs = false; }
  const drivePower = basePower + availableDeploy;
  const engineForce = Math.min(11800 * (.72 + gearRatio[carState.gear] * .42), drivePower / Math.max(speed, 18));
  const dragArea = drsActive ? .91 : 1.13;
  const drag = .5 * 1.225 * dragArea * speed * speed;
  const rolling = speed > .1 ? 170 : 0;
  const brakeForce = brake * 24800;
  let acceleration = (throttle * engineForce - brakeForce - drag - rolling) / 798;
  if (severeOff) acceleration -= speed * .65;
  else if (offTrack) acceleration -= speed * .22;
  carState.speed = clamp(carState.speed + acceleration * dt, 0, maxSpeed);

  // Hybrid harvesting under braking and when coasting; battery capacity is 4 MJ.
  const deployment = throttle > .15 && carState.ers > 0 ? (config.ersMode === 'hotlap' ? 145 : config.ersMode === 'harvest' ? 22 : 82) / 4000 : 0;
  const harvesting = (brake * 0.025 + (throttle < .08 ? .004 : 0)) * (config.ersMode === 'harvest' ? 1.7 : 1);
  carState.ers = clamp(carState.ers + (harvesting - deployment) * dt, 0, 1);
  carState.fuel = clamp(carState.fuel - (throttle * (.000055 + speed * .0000018)) * dt, 0, 1);

  // Tyre thermal and degradation model responds to load, slip and compound.
  const cornerG = Math.abs(carState.yawRate * speed) / 9.81;
  const targetTemp = compound.temp + cornerG * 5 + throttle * 3 + (offTrack ? 12 : 0);
  carState.tireTemp += (targetTemp - carState.tireTemp) * Math.min(1, dt * .055);
  const wearRate = (.00018 + cornerG * .00011 + (offTrack ? .0008 : 0)) * (config.tire === 'soft' ? 1.28 : config.tire === 'hard' ? .78 : 1);
  carState.tireWear = clamp(carState.tireWear + wearRate * dt, 0, .98);

  if (offTrack) {
    carState.offTrackTime += dt;
    $('track-status').textContent = 'OFF TRACK'; $('track-status').style.color = '#f28b6d';
    $('race-message').textContent = severeOff ? 'GRAVEL / RUNOFF — RECOVER TO THE CIRCUIT' : 'TRACK LIMITS — KEEP IT BETWEEN THE LINES';
    if (severeOff && carState.offTrackTime > 1.5) carState.health = Math.max(.4, carState.health - dt * .005);
  } else {
    carState.offTrackTime = 0;
    $('track-status').textContent = 'TRACK CLEAR'; $('track-status').style.color = 'var(--green)';
  }
  if (Math.abs(current.lateral) > 16) { carState.speed *= Math.pow(.84, dt * 10); carState.health = Math.max(.35, carState.health - dt * .018); }
  if (carState.fuel < .12) $('race-message').textContent = 'LOW FUEL — MANAGE THROTTLE';
  if (carState.ers < .08 && config.ersMode === 'hotlap') $('ers-mode').textContent = 'HARVESTING';

  // Integrate the world-space velocity in the car's local forward/right axes.
  carState.yaw += carState.yawRate * dt;
  const forward = new THREE.Vector3(Math.sin(carState.yaw), 0, Math.cos(carState.yaw));
  const right = new THREE.Vector3(Math.cos(carState.yaw), 0, -Math.sin(carState.yaw));
  const velocity = forward.multiplyScalar(carState.speed).addScaledVector(right, carState.lateralSpeed);
  carState.x += velocity.x * dt; carState.z += velocity.z * dt;
  const updated = nearestTrack(carState.x, carState.z);
  carState.currentS = updated.s;
  updateTiming(now, updated.s);

  car.root.position.set(carState.x, 0, carState.z); car.root.rotation.y = carState.yaw;
  car.chassis.rotation.z = -carState.yawRate * .08;
  car.chassis.rotation.x = clamp(carState.lateralSpeed * -.012, -.035, .035);
  const spin = carState.speed * dt / .56;
  car.wheels.forEach(w => { w.mesh.rotation.x += spin; if (w.front) w.mesh.rotation.y = -carState.steer * .19; });
  car.shadow.position.set(carState.x, .014, carState.z);
  updateHUD(now, updated);
}

function updateHUD(now, trackInfo) {
  const speedKmh = Math.round(carState.speed * 3.6);
  $('speed').textContent = String(speedKmh).padStart(3, '0');
  $('speed-fill').style.width = `${clamp(speedKmh / 360 * 100, 0, 100)}%`;
  $('gear').textContent = carState.speed < .6 ? 'N' : String(carState.gear);
  $('rpm-value').textContent = Math.round(carState.rpm).toLocaleString('en-US');
  const active = Math.round(clamp((carState.rpm - 5500) / 7500 * 18, 0, 18));
  rpmBars.forEach((bar, i) => bar.classList.toggle('active', i < active));
  $('throttle-fill').style.width = `${input.throttle * 100}%`; $('brake-fill').style.width = `${input.brake * 100}%`;
  $('throttle-value').textContent = `${Math.round(input.throttle * 100)}%`; $('brake-value').textContent = `${Math.round(input.brake * 100)}%`;
  $('steer-marker').style.left = `${50 + carState.steer * 45}%`; $('steer-value').textContent = `${Math.round(carState.steer * 100)}%`;
  $('ers-fill').style.width = `${carState.ers * 100}%`; $('ers-value').textContent = `${Math.round(carState.ers * 100)}%`;
  $('ers-mode').textContent = config.ersMode.toUpperCase();
  $('drs-status').textContent = carState.drs ? 'ACTIVE' : 'DISABLED'; $('drs-status').classList.toggle('status-off', !carState.drs);
  $('tyre-name').textContent = config.tire.toUpperCase(); $('tyre-temp').textContent = `TEMP ${Math.round(carState.tireTemp)}°C`;
  $('tyre-wear').textContent = `WEAR ${Math.round(carState.tireWear * 100)}%`;
  const tyreGrip = Math.round((1 - carState.tireWear * .42) * 100); $('tyre-grip').textContent = `GRIP ${tyreGrip}%`;
  ['tyre-fl', 'tyre-fr', 'tyre-rl', 'tyre-rr'].forEach(el => { $(el).style.borderColor = carState.tireTemp > 105 ? '#e85d36' : carState.tireTemp < 72 ? '#75a8d0' : '#84949e'; });
  $('health-fill').style.width = `${carState.health * 100}%`; $('car-health').textContent = `${Math.round(carState.health * 100)}%`;
  $('fuel-value').textContent = `${Math.round(carState.fuel * 100)}%`;
  const progress = carState.currentS / track.length; $('lap-progress-fill').style.width = `${progress * 100}%`;
  if (carState.running && !carState.paused) $('lap-time').textContent = formatTime((now - carState.lapStartedAt) / 1000);
  if (carState.running) $('lap-current').textContent = String(Math.min(carState.lapCount + 1, config.laps)).padStart(2, '0');
}

function drawMinimap() {
  const ctx = miniCtx; ctx.clearRect(0, 0, mini.width, mini.height);
  ctx.lineJoin = 'round'; ctx.lineCap = 'round';
  ctx.beginPath();
  track.samples.forEach((s, i) => { const p = mapPoint(s.point); if (i === 0) ctx.moveTo(p.x, p.y); else ctx.lineTo(p.x, p.y); }); ctx.closePath();
  ctx.strokeStyle = 'rgba(5,9,13,.7)'; ctx.lineWidth = 9; ctx.stroke();
  ctx.strokeStyle = 'rgba(224,233,235,.78)'; ctx.lineWidth = 4; ctx.stroke();
  ctx.strokeStyle = '#e85d36'; ctx.lineWidth = 1.4; ctx.stroke();
  const p = mapPoint({ x: carState.x, z: carState.z });
  ctx.save(); ctx.translate(p.x, p.y); ctx.rotate(-carState.yaw); ctx.fillStyle = '#f7f9fa'; ctx.shadowColor = '#e85d36'; ctx.shadowBlur = 9;
  ctx.beginPath(); ctx.moveTo(0, -6); ctx.lineTo(4, 5); ctx.lineTo(0, 3); ctx.lineTo(-4, 5); ctx.closePath(); ctx.fill(); ctx.restore();
}

function updateCamera(dt) {
  const pos = new THREE.Vector3(carState.x, 0, carState.z);
  const forward = new THREE.Vector3(Math.sin(carState.yaw), 0, Math.cos(carState.yaw));
  if (cameraMode === 1) {
    const desired = pos.clone().addScaledVector(forward, .63); desired.y += 1.68;
    camera.position.lerp(desired, 1 - Math.exp(-dt * 9));
    const target = pos.clone().addScaledVector(forward, 18); target.y = 1.25; camera.lookAt(target);
    camera.fov = lerp(camera.fov, 76, 1 - Math.exp(-dt * 4));
  } else {
    const followDistance = 10.5 + Math.min(carState.speed * .045, 3.6);
    const desired = pos.clone().addScaledVector(forward, -followDistance); desired.y += 4.5 + Math.min(carState.speed * .018, 1.2);
    camera.position.lerp(desired, 1 - Math.exp(-dt * 3.3));
    const target = pos.clone().addScaledVector(forward, 5 + carState.speed * .045); target.y = 1.05;
    camera.lookAt(target);
    camera.fov = lerp(camera.fov, 62 + Math.min(carState.speed * .11, 8), 1 - Math.exp(-dt * 2));
  }
  camera.updateProjectionMatrix();
}

function setCamera() { cameraMode = (cameraMode + 1) % 2; $('camera-btn').querySelector('small').textContent = cameraMode ? 'COCKPIT' : 'CHASE'; toast(cameraMode ? 'COCKPIT CAMERA' : 'CHASE CAMERA'); }

function updateInput(dt) {
  const mobile = window.matchMedia('(max-width: 760px)').matches;
  const left = keys.has('KeyA') || keys.has('ArrowLeft') || mobileLeft;
  const right = keys.has('KeyD') || keys.has('ArrowRight') || mobileRight;
  const throttle = keys.has('KeyW') || keys.has('ArrowUp') || mobileThrottle;
  const brake = keys.has('KeyS') || keys.has('ArrowDown') || keys.has('Space') || mobileBrake;
  input.steerTarget = (right ? 1 : 0) - (left ? 1 : 0);
  input.steer = lerp(input.steer, input.steerTarget, 1 - Math.exp(-dt * 7.5));
  input.throttle = lerp(input.throttle, throttle ? 1 : 0, 1 - Math.exp(-dt * 7));
  input.brake = lerp(input.brake, brake ? 1 : 0, 1 - Math.exp(-dt * 9));
}

let mobileLeft = false, mobileRight = false, mobileThrottle = false, mobileBrake = false;
function bindHoldButton(id, setter) {
  const el = $(id); const down = e => { e.preventDefault(); setter(true); };
  const up = e => { e.preventDefault(); setter(false); };
  el.addEventListener('pointerdown', down); ['pointerup', 'pointercancel', 'pointerleave'].forEach(ev => el.addEventListener(ev, up));
}
bindHoldButton('mobile-left', v => mobileLeft = v); bindHoldButton('mobile-right', v => mobileRight = v);
bindHoldButton('mobile-throttle', v => mobileThrottle = v); bindHoldButton('mobile-brake', v => mobileBrake = v);

window.addEventListener('keydown', e => {
  if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Space'].includes(e.code)) e.preventDefault();
  if (keys.has(e.code)) return;
  keys.add(e.code);
  if (e.code === 'KeyC') setCamera();
  if (e.code === 'KeyP' || e.code === 'Escape') pauseSession();
  if (e.code === 'KeyE' && carState.running && !carState.paused) {
    const s = carState.currentS / track.length;
    const available = (s > .06 && s < .22) || (s > .54 && s < .67);
    if (!available) toast('DRS NOT AVAILABLE IN THIS ZONE');
    else { carState.drs = !carState.drs; toast(carState.drs ? 'DRS OPEN' : 'DRS CLOSED'); }
  }
  if (config.transmission === 'manual' && e.code === 'ShiftLeft' || config.transmission === 'manual' && e.code === 'ShiftRight') carState.gear = Math.min(8, carState.gear + 1);
  if (config.transmission === 'manual' && e.code === 'ControlLeft' || config.transmission === 'manual' && e.code === 'ControlRight') carState.gear = Math.max(1, carState.gear - 1);
  if (e.code === 'KeyR') resetCar();
});
window.addEventListener('keyup', e => keys.delete(e.code));
window.addEventListener('blur', () => { keys.clear(); mobileLeft = mobileRight = mobileThrottle = mobileBrake = false; });

$('start-btn').addEventListener('click', beginSession);
$('pause-btn').addEventListener('click', pauseSession);
$('camera-btn').addEventListener('click', setCamera);
$('resume-btn').addEventListener('click', pauseSession);
$('again-btn').addEventListener('click', beginSession);
$('settings-btn').addEventListener('click', () => $('settings-panel').classList.toggle('hidden'));
$('close-settings').addEventListener('click', () => $('settings-panel').classList.add('hidden'));
$('reset-btn').addEventListener('click', () => { resetSession(false); $('settings-panel').classList.add('hidden'); toast('SESSION RESET'); });
$('apply-settings').addEventListener('click', () => {
  config.tire = $('tyre-select').value; config.ersMode = $('ers-select').value;
  $('settings-panel').classList.add('hidden'); $('tyre-name').textContent = config.tire.toUpperCase(); $('ers-mode').textContent = config.ersMode.toUpperCase();
  toast(`SETUP APPLIED · ${config.tire.toUpperCase()} TYRES`);
});
document.querySelectorAll('[data-transmission]').forEach(btn => btn.addEventListener('click', () => {
  config.transmission = btn.dataset.transmission; document.querySelectorAll('[data-transmission]').forEach(b => b.classList.toggle('selected', b === btn)); toast(`${config.transmission.toUpperCase()} TRANSMISSION`);
}));
document.querySelectorAll('[data-assist]').forEach(btn => btn.addEventListener('click', () => {
  config.assist = btn.dataset.assist === 'on'; document.querySelectorAll('[data-assist]').forEach(b => b.classList.toggle('selected', b === btn)); toast(`DRIVING ASSIST ${config.assist ? 'ON' : 'OFF'}`);
}));

let previous = performance.now();
function animate(now) {
  requestAnimationFrame(animate);
  const dt = Math.min((now - previous) / 1000, .035); previous = now;
  updateInput(dt);
  if (config.transmission === 'auto' && carState.running && !carState.paused) {
    if (carState.rpm > 12400 && carState.gear < 8) { carState.gear++; carState.gearShiftTimer = .16; }
    if (carState.gear > 1 && carState.speed < [0, 0, 11, 18, 25, 34, 44, 56, 70][carState.gear]) carState.gear--;
  }
  if (carState.gearShiftTimer > 0) carState.gearShiftTimer -= dt;
  physics(dt, now);
  updateCamera(dt);
  drawMinimap();
  renderer.render(scene, camera);
}

window.addEventListener('resize', () => {
  camera.aspect = window.innerWidth / window.innerHeight; camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight); renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
});

$('lap-total').textContent = String(config.laps).padStart(2, '0');
$('camera-btn').querySelector('small').textContent = 'CHASE';
resetSession(false);
updateCamera(.016); drawMinimap(); requestAnimationFrame(animate);
setTimeout(() => $('loading-screen').classList.add('done'), 1100);
setTimeout(() => $('loading-screen').remove(), 1800);
